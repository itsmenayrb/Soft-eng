<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Barangay Salitran II</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<!--
			CSS styles, fonts, libraries and frameworks goes here.
			Bootstrap, Jquery, etc..
		-->
        <?php include './libraries.php'; ?>
    </head>
    <body>
        <?php include './navigation.php'; ?>
        <a href="logout.php?logout=true" role="button">logout</a>
    </body>
</html>