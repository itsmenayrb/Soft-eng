<link rel="shortcut icon" type="image/x-icon" href="./img/favicon.ico"/>
<script type="text/javascript" src="./assets/js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="./assets/bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="./assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="./assets/font-awesome/webfonts/all.min.css">
<link rel="stylesheet" type="text/css" href="./assets/fonts/Passionfont.css">
<link rel="stylesheet" type="text/css" href="./assets/fonts/Ralewayfont.css">
<link rel="stylesheet" type="text/css" href="./assets/alertifyjs/css/alertify.min.css">
<link rel="stylesheet" type="text/css" href="./assets/css/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="assets/css/jquery.timepicker.min.css">
<link rel="stylesheet" type="text/css" href="./style.css">

<script type="text/javascript" src="./assets/js/jquery-ui.js"></script>
<script type="text/javascript" src="./assets/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="./register-validation.js"></script>
<script type="text/javascript" src="./assets/alertifyjs/alertify.min.js"></script>
<script type="text/javascript" src="./assets/js/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="./assets/js/sweetalert.min.js"></script>
<script type="text/javascript" src="./assets/js/sweetalert2.all.min.js"></script>